define({
  "_themeLabel": "Ruututeema",
  "_layout_default": "Oletusasettelu",
  "_layout_top": "Suosituin asettelu"
});