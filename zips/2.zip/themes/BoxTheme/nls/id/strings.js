define({
  "_themeLabel": "Tema Box",
  "_layout_default": "Tata letak default",
  "_layout_top": "Tata letak atas"
});