define({
  "_themeLabel": "Tema da Caixa",
  "_layout_default": "Layout padrão",
  "_layout_top": "Layout superior"
});