define({
  "_themeLabel": "Tema okvira",
  "_layout_default": "Podrazumevani raspored",
  "_layout_top": "Gornji raspored"
});