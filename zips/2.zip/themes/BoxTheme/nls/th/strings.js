define({
  "_themeLabel": "กล่องธีม",
  "_layout_default": "เค้าโครงเริ่มต้น",
  "_layout_top": "เค้าโครงด้านบน"
});