define({
  "_widgetLabel": "Kontroler okvira"
});