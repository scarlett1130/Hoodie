define({
  "_widgetLabel": "Boks-controller"
});