define({
  "_widgetLabel": "बॉक्स नियंत्रक"
});