define({
  "_widgetLabel": "Bokskontroller"
});