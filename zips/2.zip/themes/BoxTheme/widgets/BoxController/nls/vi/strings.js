define({
  "_widgetLabel": "Trình điều khiển Hộp"
});