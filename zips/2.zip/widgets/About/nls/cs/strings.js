define({
  "productVersion": "Verze produktu: ",
  "kernelVersion": "Verze jádra: ",
  "_widgetLabel": "O aplikaci"
});