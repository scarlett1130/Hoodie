define({
  "productVersion": "Produktversion: ",
  "kernelVersion": "Kernel-Version: ",
  "_widgetLabel": "Info"
});