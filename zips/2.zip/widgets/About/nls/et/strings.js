define({
  "productVersion": "Toote versioon: ",
  "kernelVersion": "Tuuma versioon: ",
  "_widgetLabel": "Info"
});