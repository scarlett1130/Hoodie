define({
  "productVersion": "Tuoteversio: ",
  "kernelVersion": "Ytimen versio: ",
  "_widgetLabel": "Tietoja"
});