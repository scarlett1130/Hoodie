define({
  "productVersion": "Versi produk: ",
  "kernelVersion": "Versi kernel: ",
  "_widgetLabel": "Tentang"
});