define({
  "productVersion": "製品バージョン: ",
  "kernelVersion": "カーネル バージョン: ",
  "_widgetLabel": "情報"
});