define({
  "productVersion": "Produkto versija: ",
  "kernelVersion": "Branduolio versija: ",
  "_widgetLabel": "Apie"
});