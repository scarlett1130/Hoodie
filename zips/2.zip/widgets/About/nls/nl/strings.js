define({
  "productVersion": "Productversie: ",
  "kernelVersion": "Kernelversie: ",
  "_widgetLabel": "Over"
});