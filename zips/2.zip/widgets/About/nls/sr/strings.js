define({
  "productVersion": "Verzija proizvoda: ",
  "kernelVersion": "Kernel verzija: ",
  "_widgetLabel": "Više o"
});