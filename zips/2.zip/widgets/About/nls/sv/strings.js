define({
  "productVersion": "Produktversion: ",
  "kernelVersion": "Kärnversion: ",
  "_widgetLabel": "Om"
});