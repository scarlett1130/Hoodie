define({
  "productVersion": "產品版本: ",
  "kernelVersion": "核心版本: ",
  "_widgetLabel": "關於"
});