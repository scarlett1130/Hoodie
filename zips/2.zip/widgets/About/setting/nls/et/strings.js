define({
  "instruction": "Looge selles vidinas kuvatav sisu.",
  "defaultContent": "Siia saate lisada teksti, lingid ja väiksemad pildid.",
  "productVersion": "Toote versioon: ",
  "kernelVersion": "Tuuma versioon: "
});